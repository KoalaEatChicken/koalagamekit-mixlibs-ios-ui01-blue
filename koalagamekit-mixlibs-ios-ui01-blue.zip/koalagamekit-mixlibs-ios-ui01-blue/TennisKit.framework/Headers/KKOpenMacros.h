#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala xQkV3wCx2OavLBMTnSco
#define KKRole umdcPZUTJgWO2F6YaIwyq
#define KKOrder e_MQneHVcC16p
#define KKUser OB4PAwpdiR_ygCu
#define KKConfig NMGOySbVqENkLZoRrU
#define KKResult CYt3TyZHuhN
#define kgk_settleBillWithOrder fcGn3yLBbE6T_wU
#define kgk_postRoleInfoWithModel pvQts9leTyp7Pd8
#define kgk_switchAccounts f8TQ9a6MRrvFSq
#define kgk_openLog o9SyE8OH6MoK4Tc5BfdD
#define kgk_loginWithViewController wNdhAR2mLpTr
#define kgk_initGameKitWithCompletionHandler yYgk_xezq0Xl
#define kgk_demo_setPkver xhkMGTHQmBi8

#endif
