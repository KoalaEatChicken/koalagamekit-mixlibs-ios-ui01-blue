#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala tdvHszWqoN5xr
#define KKRole DZzO9QXNYUM0
#define KKOrder MnAfLx5mS1NhE
#define KKUser mIT_APXOwSuqG
#define KKConfig IgyUHz9h74e_1t3o
#define KKResult dpViq2xNAvbz867HDX
#define kgk_settleBillWithOrder IL4zsCFbuaKVZp
#define kgk_postRoleInfoWithModel OR6aZW4Bwfespvt
#define kgk_switchAccounts rqut5jAWXk_zo0GbK
#define kgk_openLog OG75NI4stpnig
#define kgk_loginWithViewController Tg9ok3GJ0ATsX
#define kgk_initGameKitWithCompletionHandler LJt7jASNZeH2Ru
#define kgk_demo_setPkver OsNAyDP3qtk2WVC8KUG

#endif
